package com.musicassistant.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** L'assistant qui parle : synthèse vocale Android (hors ligne si la voix française est installée). */
class VoiceOutput(context: Context) : TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var currentId: String? = null
    private var callback: (() -> Unit)? = null

    var ready = false
        private set
    var onInitResult: ((Boolean) -> Unit)? = null

    override fun onInit(status: Int) {
        val engine = tts
        if (status == TextToSpeech.SUCCESS && engine != null) {
            val r = engine.setLanguage(Locale.FRENCH)
            ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { finish(utteranceId) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { finish(utteranceId) }
            })
        }
        main.post { onInitResult?.invoke(ready) }
    }

    private fun finish(id: String?) {
        main.post {
            if (id != null && id == currentId) {
                val cb = callback
                callback = null
                cb?.invoke()
            }
        }
    }

    fun speak(text: String, onDone: () -> Unit) {
        val engine = tts
        if (!ready || engine == null) {
            onDone()
            return
        }
        val id = "u" + System.nanoTime()
        currentId = id
        callback = onDone
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stop() {
        currentId = null
        callback = null
        tts?.stop()
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
