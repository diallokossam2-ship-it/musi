package com.musicassistant.app

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: Uri
) {
    val titleTokens: List<String> by lazy(LazyThreadSafetyMode.NONE) { TextUtils.tokens(title) }
    val artistTokens: List<String> by lazy(LazyThreadSafetyMode.NONE) { TextUtils.tokens(artist) }
    val allTokens: List<String> by lazy(LazyThreadSafetyMode.NONE) { titleTokens + artistTokens }

    fun toMediaItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artist)
                    .build()
            )
            .build()
}
