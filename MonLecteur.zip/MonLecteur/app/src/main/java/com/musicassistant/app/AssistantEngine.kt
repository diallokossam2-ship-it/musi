package com.musicassistant.app

/** Ce que l'assistant sait faire sur le lecteur. */
interface PlayerBridge {
    fun isReady(): Boolean
    fun play(tracks: List<Track>, startIndex: Int = 0): Boolean
    fun pause()
    fun resume()
    fun next()
    fun previous()
    fun setVolumePercent(percent: Int): Int
    fun changeVolumePercent(delta: Int): Int
    fun currentTrackLabel(): String?
}

/**
 * Le "cerveau" de l'assistant : comprend la commande, agit sur le lecteur,
 * et pose une question quand il y a plusieurs choix (ex : deux chansons de Dena Mwana).
 */
class AssistantEngine(
    private val player: PlayerBridge,
    private val library: () -> List<Track>
) {

    data class Reply(val text: String, val expectAnswer: Boolean = false)

    private var pending: List<Track>? = null
    private var pendingTries = 0

    fun handle(raw: String): Reply {
        val candidates = pending
        if (candidates != null) {
            val r = resolvePending(raw, candidates)
            if (r != null) return r
        }
        return execute(CommandParser.parse(raw))
    }

    // ------------------------------------------------------------------

    private fun execute(cmd: Command): Reply = when (cmd) {
        is Command.Play -> {
            if (library().isEmpty()) {
                Reply("Je ne trouve aucune musique sur le téléphone.")
            } else {
                val group = findGroup(cmd.query)
                if (group.isEmpty()) Reply("Je n'ai pas trouvé ${cmd.query} dans ta musique.")
                else playOrAsk(group)
            }
        }
        Command.PlayAll -> {
            if (library().isEmpty()) Reply("Je ne trouve aucune musique sur le téléphone.")
            else if (player.play(library().shuffled().take(MAX_QUEUE))) Reply("Je lance un mix de ta musique.")
            else Reply("Le lecteur n'est pas encore prêt.")
        }
        Command.Pause -> { player.pause(); Reply("D'accord, pause.") }
        Command.Resume -> { player.resume(); Reply("C'est reparti.") }
        Command.Next -> { player.next(); Reply("Titre suivant.") }
        Command.Previous -> { player.previous(); Reply("Titre précédent.") }
        Command.Mute -> { player.setVolumePercent(0); Reply("Son coupé.") }
        is Command.SetVolume -> {
            val v = player.setVolumePercent(cmd.percent)
            Reply("Volume à $v pour cent.")
        }
        is Command.ChangeVolume -> {
            val v = player.changeVolumePercent(cmd.delta)
            Reply("Volume à $v pour cent.")
        }
        Command.WhatsPlaying -> {
            val label = player.currentTrackLabel()
            if (label == null) Reply("Rien n'est en lecture.") else Reply("C'est $label.")
        }
        Command.Unknown -> Reply("Je n'ai pas compris. Dis par exemple : joue Emmanuel, ou mets le volume à vingt pour cent.")
    }

    /** Cherche les morceaux qui correspondent le mieux (titre, artiste, ou les deux). */
    private fun findGroup(query: String): List<Track> {
        val q = TextUtils.tokens(query)
        if (q.isEmpty()) return emptyList()
        val scored = library()
            .map { t ->
                t to maxOf(
                    TextUtils.score(q, t.titleTokens),
                    TextUtils.score(q, t.artistTokens),
                    TextUtils.score(q, t.allTokens)
                )
            }
            .filter { it.second >= MIN_SCORE }
            .sortedByDescending { it.second }
        if (scored.isEmpty()) return emptyList()
        val top = scored[0].second
        return scored
            .filter { it.second >= top - 0.04 }
            .map { it.first }
            .distinctBy { TextUtils.normalize(it.title) + "|" + TextUtils.normalize(it.artist) }
    }

    private fun playOrAsk(group: List<Track>): Reply {
        if (group.size == 1) return playTracks(group)
        pending = group
        pendingTries = 0
        return Reply(describe(group), expectAnswer = true)
    }

    private fun describe(group: List<Track>): String {
        val artists = group.map { it.artist }.distinct()
        val common = if (artists.size == 1 && artists[0] != MusicRepository.UNKNOWN_ARTIST) artists[0] else null
        val n = group.size
        if (n > 5) {
            val de = if (common != null) " de $common" else ""
            return "J'ai trouvé $n morceaux$de. Dis-moi le titre, ou dis toutes pour tout lancer."
        }
        val names = group.map { if (common != null) it.title else "${it.title}, de ${it.artist}" }
        val list = names.dropLast(1).joinToString(", ") + " ou " + names.last()
        val head = if (common != null) "J'ai $n morceaux de $common" else "J'ai trouvé $n morceaux"
        return "$head : $list. Lequel veux-tu ?"
    }

    private fun playTracks(tracks: List<Track>): Reply {
        val queue = tracks.take(MAX_QUEUE)
        if (!player.play(queue)) return Reply("Le lecteur n'est pas encore prêt.")
        if (queue.size == 1) {
            val t = queue[0]
            return if (t.artist == MusicRepository.UNKNOWN_ARTIST) Reply("Je lance ${t.title}.")
            else Reply("Je lance ${t.title}, de ${t.artist}.")
        }
        return Reply("Je lance ${queue.size} morceaux.")
    }

    // ------------------------------------------------------------------
    // Réponse à une question de l'assistant ("lequel veux-tu ?")

    private fun clearPending() {
        pending = null
        pendingTries = 0
    }

    private fun resolvePending(raw: String, cands: List<Track>): Reply? {
        val words = TextUtils.tokens(raw)
        if (words.any { it in CANCEL_WORDS }) {
            clearPending()
            return Reply("D'accord, j'annule.")
        }
        val cmd = CommandParser.parse(raw)
        if (cmd !is Command.Play && cmd !is Command.Unknown) {
            // L'utilisateur donne une autre commande (volume, pause...) : on oublie la question.
            clearPending()
            return null
        }
        if (words.any { it in ALL_WORDS }) {
            clearPending()
            return playTracks(cands)
        }

        val idx = ordinalIndex(words, cands.size)
        if (idx != null) {
            clearPending()
            return playTracks(listOf(cands[idx]))
        }

        val queryText = if (cmd is Command.Play) cmd.query else CommandParser.queryOf(raw)
        val q = TextUtils.tokens(queryText)
        if (q.isNotEmpty()) {
            val scored = cands
                .map { it to TextUtils.score(q, it.titleTokens) }
                .sortedByDescending { it.second }
            val best = scored[0]
            val second = scored.getOrNull(1)
            if (best.second >= MIN_SCORE && (second == null || best.second - second.second >= 0.1)) {
                clearPending()
                return playTracks(listOf(best.first))
            }
        }

        pendingTries++
        if (pendingTries >= 2) {
            clearPending()
            return Reply("Je n'ai pas compris, on laisse tomber.")
        }
        return Reply("Je n'ai pas bien compris. ${describe(cands)}", expectAnswer = true)
    }

    private fun ordinalIndex(words: List<String>, size: Int): Int? {
        for (w in words) {
            val i = when (w) {
                "premier", "premiere" -> 0
                "deuxieme", "second", "seconde" -> 1
                "troisieme" -> 2
                "quatrieme" -> 3
                "cinquieme" -> 4
                "dernier", "derniere" -> size - 1
                else -> null
            }
            if (i != null && i in 0 until size) return i
        }
        if (words.size == 1) {
            val i = when (words[0]) {
                "un", "une" -> 0
                "deux" -> 1
                "trois" -> 2
                "quatre" -> 3
                "cinq" -> 4
                else -> null
            }
            if (i != null && i < size) return i
        }
        return null
    }

    companion object {
        private const val MIN_SCORE = 0.75
        private const val MAX_QUEUE = 300
        private val CANCEL_WORDS = setOf("annule", "annuler", "laisse", "oublie", "non")
        private val ALL_WORDS = setOf("toutes", "tous", "tout", "toute")
    }
}
