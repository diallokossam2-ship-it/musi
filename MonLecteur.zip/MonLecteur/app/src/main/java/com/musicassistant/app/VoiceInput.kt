package com.musicassistant.app

import android.content.Context
import android.content.res.AssetManager
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import kotlin.concurrent.thread

/** Les oreilles de l'assistant : reconnaissance vocale Vosk, 100% hors ligne. */
class VoiceInput(private val context: Context) {

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var service: SpeechService? = null
    private var token = 0

    @Volatile
    var isReady = false
        private set

    /** Copie le modèle depuis les assets (une seule fois) puis le charge. */
    fun load(onReady: () -> Unit, onError: (String) -> Unit) {
        thread(name = "vosk-load") {
            try {
                if (context.assets.list(MODEL_ASSET).isNullOrEmpty()) {
                    throw IllegalStateException("Modèle vocal absent de l'application.")
                }
                val dir = File(context.filesDir, "vosk-model")
                val marker = File(dir, ".ok")
                if (!marker.exists()) {
                    dir.deleteRecursively()
                    copyAssets(context.assets, MODEL_ASSET, dir)
                    marker.createNewFile()
                }
                val m = Model(dir.absolutePath)
                model = m
                recognizer = Recognizer(m, 16000f)
                isReady = true
                main.post { onReady() }
            } catch (e: Throwable) {
                main.post { onError(e.message ?: "Erreur de chargement de l'assistant") }
            }
        }
    }

    private fun copyAssets(am: AssetManager, path: String, dest: File) {
        val children = am.list(path) ?: emptyArray()
        if (children.isEmpty()) {
            try {
                dest.parentFile?.mkdirs()
                am.open(path).use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
            } catch (_: java.io.FileNotFoundException) {
                // dossier vide : on ignore
            }
        } else {
            dest.mkdirs()
            for (name in children) copyAssets(am, "$path/$name", File(dest, name))
        }
    }

    fun listen(onText: (String) -> Unit, onFail: (String) -> Unit) {
        val rec = recognizer
        if (!isReady || rec == null) {
            onFail("L'assistant n'est pas encore prêt.")
            return
        }
        stopService()
        val mine = ++token
        try {
            rec.reset()
            val svc = SpeechService(rec, 16000f)
            service = svc
            svc.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) {}

                override fun onResult(hypothesis: String?) {
                    if (mine != token) return
                    val text = textOf(hypothesis)
                    if (text.isNotBlank()) {
                        token++
                        stopService()
                        onText(text)
                    }
                }

                override fun onFinalResult(hypothesis: String?) {
                    if (mine != token) return
                    token++
                    stopService()
                    val text = textOf(hypothesis)
                    if (text.isNotBlank()) onText(text) else onFail("Je n'ai rien entendu.")
                }

                override fun onError(exception: Exception?) {
                    if (mine != token) return
                    token++
                    stopService()
                    onFail(exception?.message ?: "Erreur du micro")
                }

                override fun onTimeout() {
                    if (mine != token) return
                    token++
                    stopService()
                    onFail("Je n'ai rien entendu.")
                }
            }, 10000)
        } catch (e: Exception) {
            token++
            onFail(e.message ?: "Micro indisponible")
        }
    }

    fun cancel() {
        token++
        stopService()
    }

    private fun textOf(json: String?): String =
        try {
            JSONObject(json ?: "{}").optString("text", "").trim()
        } catch (_: Exception) {
            ""
        }

    private fun stopService() {
        val svc = service ?: return
        service = null
        svc.stop()
        // on libère le micro un peu plus tard, le temps que le thread d'écoute se termine
        main.postDelayed({ try { svc.shutdown() } catch (_: Exception) {} }, 700)
    }

    fun release() {
        cancel()
        main.postDelayed({
            try { recognizer?.close() } catch (_: Exception) {}
            try { model?.close() } catch (_: Exception) {}
            recognizer = null
            model = null
        }, 900)
    }

    companion object {
        private const val MODEL_ASSET = "model-fr"
    }
}
