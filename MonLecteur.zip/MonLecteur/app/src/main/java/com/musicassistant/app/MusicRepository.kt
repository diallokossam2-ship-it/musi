package com.musicassistant.app

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

class MusicRepository(private val context: Context) {

    /** Lit toute la musique du téléphone (MediaStore), sans internet. */
    fun loadTracks(): List<Track> {
        val collection = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val result = ArrayList<Track>()

        context.contentResolver.query(
            collection, projection, selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val title = (c.getString(titleCol) ?: "").trim().ifEmpty { "Sans titre" }
                var artist = (c.getString(artistCol) ?: "").trim()
                if (artist.isEmpty() || artist == "<unknown>") artist = UNKNOWN_ARTIST
                result.add(Track(id, title, artist, ContentUris.withAppendedId(collection, id)))
            }
        }
        return result
    }

    companion object {
        const val UNKNOWN_ARTIST = "Artiste inconnu"
    }
}
