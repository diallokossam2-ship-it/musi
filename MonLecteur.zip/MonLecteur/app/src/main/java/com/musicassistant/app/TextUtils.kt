package com.musicassistant.app

import java.text.Normalizer

object TextUtils {
    private val diacritics = Regex("\\p{InCombiningDiagonalMarks}+")
    private val nonAlnum = Regex("[^a-z0-9 ]")
    private val spaces = Regex("\\s+")

    /** minuscules, sans accents, sans ponctuation. "20%" devient "20 pour cent". */
    fun normalize(s: String): String {
        val lower = s.lowercase()
            .replace("%", " pour cent ")
            .replace("œ", "oe")
            .replace("æ", "ae")
        val nfd = Normalizer.normalize(lower, Normalizer.Form.NFD)
        return nfd.replace(diacritics, "")
            .replace(nonAlnum, " ")
            .replace(spaces, " ")
            .trim()
    }

    fun tokens(s: String): List<String> =
        normalize(s).split(" ").filter { it.isNotEmpty() }

    fun similarity(a: String, b: String): Double {
        if (a == b) return 1.0
        val m = maxOf(a.length, b.length)
        if (m == 0) return 1.0
        return 1.0 - levenshtein(a, b).toDouble() / m
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }

    /** Score 0..1 : pour chaque mot cherché, on prend le mot le plus proche de la cible. */
    fun score(query: List<String>, target: List<String>): Double {
        if (query.isEmpty() || target.isEmpty()) return 0.0
        var sum = 0.0
        for (q in query) {
            var best = 0.0
            for (t in target) {
                val s = similarity(q, t)
                if (s > best) best = s
            }
            sum += best
        }
        return sum / query.size
    }

    private val NUMBERS = mapOf(
        "zero" to 0, "un" to 1, "une" to 1, "deux" to 2, "trois" to 3, "quatre" to 4,
        "cinq" to 5, "six" to 6, "sept" to 7, "huit" to 8, "neuf" to 9, "dix" to 10,
        "onze" to 11, "douze" to 12, "treize" to 13, "quatorze" to 14, "quinze" to 15,
        "seize" to 16, "vingt" to 20, "vingts" to 20, "trente" to 30, "quarante" to 40,
        "cinquante" to 50, "soixante" to 60, "cent" to 100
    )

    /** Lit un nombre en chiffres ou en lettres françaises : "vingt", "soixante et onze", "quatre vingt dix". */
    fun parseNumber(tokens: List<String>): Int? {
        var total = 0
        var found = false
        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            val digits = t.toIntOrNull()
            if (digits != null) {
                total += digits
                found = true
            } else if (t == "quatre" && i + 1 < tokens.size && (tokens[i + 1] == "vingt" || tokens[i + 1] == "vingts")) {
                total += 80
                found = true
                i++
            } else if (NUMBERS.containsKey(t)) {
                total += NUMBERS.getValue(t)
                found = true
            } else if (t == "et" && found) {
                // "soixante et onze"
            } else if (found) {
                break
            }
            i++
        }
        return if (found) total else null
    }
}
