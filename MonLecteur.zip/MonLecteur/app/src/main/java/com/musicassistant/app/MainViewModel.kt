package com.musicassistant.app

import android.app.Application
import android.content.ComponentName
import android.media.AudioManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class MainViewModel(app: Application) : AndroidViewModel(app), PlayerBridge {

    var tracks by mutableStateOf<List<Track>>(emptyList())
        private set
    var nowTitle by mutableStateOf("")
        private set
    var nowArtist by mutableStateOf("")
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var status by mutableStateOf("Chargement de l'assistant…")
        private set
    var lastHeard by mutableStateOf("")
        private set
    var lastReply by mutableStateOf("")
        private set
    var assistantReady by mutableStateOf(false)
        private set
    var listening by mutableStateOf(false)
        private set

    private val repo = MusicRepository(app)
    private val audio = app.getSystemService(AudioManager::class.java)
    private val voiceIn = VoiceInput(app)
    private val voiceOut = VoiceOutput(app)
    private val engine = AssistantEngine(this) { tracks }
    private var controller: MediaController? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            this@MainViewModel.isPlaying = isPlaying
        }

        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
            nowTitle = mediaMetadata.title?.toString().orEmpty()
            nowArtist = mediaMetadata.artist?.toString().orEmpty()
        }
    }

    init {
        connectController()
        voiceOut.onInitResult = { ok ->
            if (!ok) lastReply = "Voix française absente : Paramètres > Synthèse vocale > installer le français."
        }
        voiceIn.load(
            onReady = {
                assistantReady = true
                status = "Prêt. Appuie sur le micro et parle."
            },
            onError = { msg -> status = "Assistant indisponible : $msg" }
        )
    }

    // ---------------------------------------------------------- bibliothèque

    fun loadLibrary() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = try {
                repo.loadTracks()
            } catch (e: SecurityException) {
                emptyList()
            }
            withContext(Dispatchers.Main) { tracks = list }
        }
    }

    fun playFromList(index: Int) {
        val all = tracks
        if (index !in all.indices) return
        val queue = (all.drop(index) + all.take(index)).take(300)
        play(queue, 0)
    }

    // ---------------------------------------------------------- assistant vocal

    fun onMicClicked() {
        if (listening) {
            voiceIn.cancel()
            listening = false
            duck(false)
            status = "Prêt. Appuie sur le micro et parle."
            return
        }
        startListening()
    }

    private fun startListening() {
        voiceOut.stop()
        duck(true)
        listening = true
        status = "Je t'écoute…"
        voiceIn.listen(
            onText = { text ->
                listening = false
                handleSpeech(text)
            },
            onFail = { msg ->
                listening = false
                duck(false)
                status = msg
            }
        )
    }

    private fun handleSpeech(text: String) {
        lastHeard = text
        val reply = engine.handle(text)
        lastReply = reply.text
        status = "Je réponds…"
        voiceOut.speak(reply.text) {
            if (reply.expectAnswer) {
                startListening()
            } else {
                duck(false)
                status = "Prêt. Appuie sur le micro et parle."
            }
        }
    }

    /** Baisse la musique pendant que l'assistant écoute ou parle (meilleure reconnaissance). */
    private fun duck(on: Boolean) {
        controller?.volume = if (on) 0.1f else 1f
    }

    // ---------------------------------------------------------- lecteur

    private fun connectController() {
        val ctx = getApplication<Application>()
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(playerListener)
                c.repeatMode = Player.REPEAT_MODE_ALL
                nowTitle = c.mediaMetadata.title?.toString().orEmpty()
                nowArtist = c.mediaMetadata.artist?.toString().orEmpty()
                isPlaying = c.isPlaying
            } catch (e: Exception) {
                lastReply = "Lecteur indisponible : ${e.message}"
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    override fun isReady(): Boolean = controller != null

    override fun play(tracks: List<Track>, startIndex: Int): Boolean {
        val c = controller ?: return false
        if (tracks.isEmpty()) return false
        c.setMediaItems(tracks.map { it.toMediaItem() }, startIndex, 0L)
        c.prepare()
        c.play()
        return true
    }

    override fun pause() { controller?.pause() }
    override fun resume() { controller?.play() }
    override fun next() { controller?.seekToNextMediaItem() }
    override fun previous() { controller?.seekToPreviousMediaItem() }

    override fun setVolumePercent(percent: Int): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val p = percent.coerceIn(0, 100)
        val level = (p * max / 100.0).roundToInt()
        try {
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, level, AudioManager.FLAG_SHOW_UI)
        } catch (_: SecurityException) {
        }
        return currentVolumePercent()
    }

    override fun changeVolumePercent(delta: Int): Int =
        setVolumePercent(currentVolumePercent() + delta)

    private fun currentVolumePercent(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (max <= 0) return 0
        return (audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100.0 / max).roundToInt()
    }

    override fun currentTrackLabel(): String? {
        val m = controller?.mediaMetadata ?: return null
        val title = m.title?.toString()
        if (title.isNullOrEmpty()) return null
        val artist = m.artist?.toString()
        return if (artist.isNullOrEmpty() || artist == MusicRepository.UNKNOWN_ARTIST) title else "$title, de $artist"
    }

    override fun onCleared() {
        voiceOut.shutdown()
        voiceIn.release()
        controller?.release()
        controller = null
        super.onCleared()
    }
}
