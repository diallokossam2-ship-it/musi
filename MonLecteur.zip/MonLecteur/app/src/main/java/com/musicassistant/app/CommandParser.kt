package com.musicassistant.app

sealed class Command {
    data class Play(val query: String) : Command()
    object PlayAll : Command()
    object Pause : Command()
    object Resume : Command()
    object Next : Command()
    object Previous : Command()
    object Mute : Command()
    object WhatsPlaying : Command()
    data class SetVolume(val percent: Int) : Command()
    data class ChangeVolume(val delta: Int) : Command()
    object Unknown : Command()
}

/**
 * Comprend les commandes en français, 100% hors ligne.
 * Pour ajouter une façon de parler : ajoute un mot dans les listes ci-dessous.
 */
object CommandParser {

    private val PLAY_VERBS = setOf(
        "joue", "jouer", "jouez", "mets", "met", "mettre", "lance", "lancer",
        "ecoute", "ecouter", "demarre", "passe", "play"
    )

    private val FILLER = setOf(
        "le", "la", "les", "l", "un", "une", "des", "de", "du", "d", "a", "au", "aux", "et",
        "moi", "me", "m", "s", "t", "te", "il", "plait", "svp", "stp", "musique", "chanson",
        "morceau", "titre", "son", "celle", "celui", "ceux", "ce", "cette", "cet", "qui", "que",
        "qu", "est", "par", "chante", "pour", "en", "y", "je", "veux", "voudrais", "peux",
        "tu", "patron", "assistant", "ok", "alors", "donc", "encore", "aussi", "mon", "ma", "mes"
    )

    private val CONTROL = setOf(
        "suivant", "suivante", "prochain", "prochaine", "next", "saute", "skip",
        "precedent", "precedente", "reviens", "retour", "pause", "stop", "arrete", "arreter",
        "tais", "silence", "reprends", "reprend", "reprendre", "continue", "resume", "relance",
        "play", "aleatoire", "melange", "shuffle"
    )

    /** Ce qui reste quand on enlève les verbes et les petits mots : le nom de l'artiste ou du titre. */
    fun queryOf(raw: String): String =
        TextUtils.tokens(raw).filter { it !in FILLER && it !in PLAY_VERBS }.joinToString(" ")

    fun parse(raw: String): Command {
        val n = TextUtils.normalize(raw)
        if (n.isEmpty()) return Command.Unknown
        val t = n.split(" ")

        fun has(vararg w: String) = w.any { it in t }
        fun phrase(vararg p: String) = p.any { n.contains(it) }

        val query = queryOf(raw)
        val hasVerb = t.any { it in PLAY_VERBS }
        val queryHasContent = query.split(" ").any { it.isNotEmpty() && it !in CONTROL }

        // ---- Volume ----
        if (phrase("coupe le son", "mute", "muet", "sans son")) return Command.Mute

        val number = if (phrase("un peu")) null else TextUtils.parseNumber(t)
        val up = (has("monte", "augmente", "hausse") && has("volume", "son")) || phrase("plus fort")
        val down = (has("baisse", "diminue", "descends", "reduis") && has("volume", "son")) || phrase("moins fort")

        if (up || down) {
            val sign = if (up) 1 else -1
            return if (number != null && has("a")) {
                Command.SetVolume(number.coerceIn(0, 100))
            } else {
                Command.ChangeVolume(sign * (number ?: 10).coerceIn(1, 100))
            }
        }
        if (has("volume") || phrase("pour cent")) {
            if (phrase("a fond", "maximum")) return Command.SetVolume(100)
            if (phrase("moitie")) return Command.SetVolume(50)
            if (number != null) return Command.SetVolume(number.coerceIn(0, 100))
        }

        // ---- Lecture d'un artiste / titre ----
        if (hasVerb && queryHasContent) return Command.Play(query)

        // ---- Commandes du lecteur ----
        if (has("suivant", "suivante", "prochain", "prochaine", "next", "saute", "skip") ||
            (has("passe") && query.isEmpty())
        ) return Command.Next
        if (has("precedent", "precedente", "reviens", "retour")) return Command.Previous
        if (phrase("qui joue", "qui chante", "quoi cette", "quel est ce titre", "quelle est cette")) {
            return Command.WhatsPlaying
        }
        if (has("pause", "stop", "arrete", "arreter", "tais", "silence")) return Command.Pause
        if (has("reprends", "reprend", "reprendre", "continue", "resume", "relance") || n == "play") {
            return Command.Resume
        }
        if (hasVerb) return Command.PlayAll
        if (has("aleatoire", "melange", "shuffle")) return Command.PlayAll
        return Command.Unknown
    }
}
