package com.musicassistant.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            vm.loadLibrary()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    PlayerScreen(vm, onMic = { onMic() })
                }
            }
        }
        askPermissions()
    }

    private fun askPermissions() {
        val wanted = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) {
            wanted.add(Manifest.permission.READ_MEDIA_AUDIO)
            wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            wanted.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) vm.loadLibrary() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun onMic() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.onMicClicked()
        else permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
    }
}

@Composable
fun PlayerScreen(vm: MainViewModel, onMic: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Mon Lecteur", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    vm.nowTitle.ifEmpty { "Rien en lecture" },
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1
                )
                Text(vm.nowArtist, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Button(onClick = { vm.previous() }) { Text("⏮") }
                    Button(onClick = { if (vm.isPlaying) vm.pause() else vm.resume() }) {
                        Text(if (vm.isPlaying) "⏸" else "▶")
                    }
                    Button(onClick = { vm.next() }) { Text("⏭") }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(vm.status, style = MaterialTheme.typography.bodyLarge)
                if (vm.lastHeard.isNotEmpty()) Text("Toi : ${vm.lastHeard}")
                if (vm.lastReply.isNotEmpty()) Text("Assistant : ${vm.lastReply}")
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onMic,
                    enabled = vm.assistantReady,
                    modifier = Modifier.fillMaxWidth().height(64.dp)
                ) {
                    Text(if (vm.listening) "Arrêter" else "🎤  Parler")
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("Ma musique (${vm.tracks.size})", style = MaterialTheme.typography.titleSmall)

        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(vm.tracks) { index, track ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.playFromList(index) }
                        .padding(vertical = 10.dp)
                ) {
                    Text(track.title, maxLines = 1)
                    Text(track.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                }
            }
        }
    }
}
