# Mon Lecteur — lecteur de musique + assistant vocal 100% hors ligne

1. Télécharge `vosk-model-small-fr-0.22` sur https://alphacephei.com/vosk/models
2. Dézippe-le et mets son CONTENU (am, conf, graph, ivector...) dans `app/src/main/assets/model-fr/`
   (supprime `PUT_VOSK_MODEL_HERE.txt`).
3. Push sur GitHub : l'onglet Actions compile et te donne l'APK (Artifacts).

Exemples : "joue Dena Mwana" -> l'assistant demande lequel -> "celle d'Emmanuel".
"mets le volume à vingt pour cent", "pause", "suivant", "monte le son", "c'est quoi cette chanson".
