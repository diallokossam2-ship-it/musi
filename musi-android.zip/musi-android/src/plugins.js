import { Capacitor } from '@capacitor/core';
import { SpeechRecognition } from '@capacitor-community/speech-recognition';
import { TextToSpeech } from '@capacitor-community/text-to-speech';
import { MediaSession } from '@jofr/capacitor-media-session';
import { BackgroundMode } from '@anuradev/capacitor-background-mode';
// Exposé seulement dans l'app Android ; dans un navigateur, Musi utilise les API web.
if (Capacitor.isNativePlatform()) window.MusiNative = { Capacitor, SpeechRecognition, TextToSpeech, MediaSession, BackgroundMode };
