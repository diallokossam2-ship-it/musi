# Musi : compiler l'APK

Prérequis : Node.js 20+, Android Studio (avec SDK Android) et Java 17+.

```bash
npm install            # si conflit de versions : npm install --legacy-peer-deps
npm run build:js       # regroupe les plugins natifs dans www/plugins.js
npx cap add android    # une seule fois
npm run android        # sync + permissions + ouvre Android Studio
```
Dans Android Studio : **Build > Build APK(s)**. L'APK est dans `android/app/build/outputs/apk/debug/`.
Sans interface : `cd android && ./gradlew assembleDebug`.

## Sur le téléphone
1. Au premier toucher, accepte micro et notifications (la notification permet à Musi de rester actif écran verrouillé).
2. Bibliothèque > **Ajouter des fichiers** (sélection multiple). Le bouton « Un dossier » peut ne pas marcher dans Android.
3. Hors ligne : télécharge le pack vocal dans Réglages Android > Langues > Reconnaissance vocale (Google) > Hors connexion.

## Limites connues
- « Musi » repose sur la reconnaissance Android relancée en boucle : sur certains téléphones, un petit bip ou clic se répète, et la batterie est plus sollicitée. Pour un vrai mot d'activation léger, remplace le moteur par Vosk ou Porcupine dans `STT.engines` (voir `NATIVE_STT` dans www/index.html).
- La bibliothèque n'est pas conservée entre deux lancements. Il faudra un plugin de scan natif (MediaStore) pour la rendre automatique.
- Ce projet n'a pas pu être compilé ni testé ici (pas d'Internet ni de SDK Android).

## Mise à jour (v2)
- Pendant la musique, l'écoute de « Musi » est suspendue : Android coupe la musique dès qu'une reconnaissance vocale démarre. Utilise le bouton 🎙️ (la musique se met en pause pendant que tu parles, puis reprend). Le mot d'activation écoute quand la musique est en pause.
- Voix : moteur de synthèse Android (installe Synthèse vocale Google avec la voix française).
- Désinstalle l'ancien Musi avant d'installer un nouvel APK (la signature de test change à chaque compilation).
