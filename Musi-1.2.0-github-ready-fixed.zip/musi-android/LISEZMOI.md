# Musi 1.2 — lecteur musical vocal Android

Musi est un lecteur musical local avec bibliothèque, playlists, commandes vocales, réponses vocales, lecture en arrière-plan et contrôles multimédias.

## Compilation gratuite avec GitHub Actions

Le dépôt contient `.github/workflows/build-apk.yml`.

1. Créez un dépôt GitHub et envoyez tout le contenu de ce dossier.
2. Ouvrez **Actions → Musi Android APK → Run workflow** (ou poussez sur `main`).
3. Le workflow installe Node 22 et Java 17, prépare Capacitor, génère le projet Android si nécessaire et lance `assembleDebug`.
4. À la fin, téléchargez l'artefact **Musi-debug-apk** dans la page du workflow.

Aucun ordinateur Android Studio n'est requis pour cette compilation GitHub.

## Architecture vocale actuelle

La version actuelle conserve un moteur vocal Android/Capacitor et le TTS système pour rester légère. Le code est organisé pour pouvoir remplacer le moteur vocal par un moteur embarqué local (VAD + keyword spotting + vérification du locuteur + ASR/TTS) sans refaire le lecteur.

**Important :** le moteur Android de reconnaissance vocale peut dépendre du service vocal configuré sur le téléphone. Le mode totalement autonome avec vérification de la voix nécessite l'intégration de modèles embarqués dédiés. Nous ne les ajoutons pas aveuglément : les modèles IA peuvent peser beaucoup plus que l'application elle-même.

## Taille

L'interface et le code Musi restent volontairement sans framework UI lourd. Les modèles IA ne sont pas inclus dans cette version afin de garder l'APK léger. Lors de leur intégration, nous choisirons des modèles compacts et uniquement `arm64-v8a` pour cibler les téléphones modernes compatibles.

## Audio et voix

- La bibliothèque est locale.
- Les commandes musicales ne nécessitent pas de serveur Musi.
- Musi peut répondre à voix haute via le moteur TTS Android.
- Pour une réponse vocale française fiable sur Samsung, une voix française doit être installée dans le moteur TTS du téléphone.

## Commandes

Suivant, précédent, pause, reprise, arrêt, répétition, aléatoire, volume, recherche de morceau/artiste et lecture de playlist sont déjà prévus. La couche de commandes est volontairement séparée du moteur vocal.

## Signature

L'APK généré par GitHub Actions est un APK de debug signé avec la clé de debug du build. Pour une publication Play Store, une étape de signature release avec un keystore doit être ajoutée séparément.
