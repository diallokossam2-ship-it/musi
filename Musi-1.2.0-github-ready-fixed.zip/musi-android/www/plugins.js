/* remplacé par: npm run build:js */
