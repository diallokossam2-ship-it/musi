#!/bin/bash
# Ajoute les permissions Android requises (à lancer après "npx cap add android"). Sans danger si relancé.
M=android/app/src/main/AndroidManifest.xml
[ -f "$M" ] || { echo "Lance d'abord: npx cap add android"; exit 1; }
grep -q FOREGROUND_SERVICE_MICROPHONE "$M" && { echo "Manifeste déjà prêt."; exit 0; }
BLOCK='<uses-permission android:name="android.permission.RECORD_AUDIO"/>\n<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>\n<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>\n<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>\n<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE"/>\n<uses-permission android:name="android.permission.WAKE_LOCK"/>\n<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n<uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>\n<queries><intent><action android:name="android.speech.RecognitionService"/></intent><intent><action android:name="android.intent.action.TTS_SERVICE"/></intent></queries>'
sed -i "s|<application|$BLOCK\n<application|" "$M"
echo "Permissions ajoutées."
