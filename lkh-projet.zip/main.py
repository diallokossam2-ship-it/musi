from kivy.app import App
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput

import moteur

Window.softinput_mode = "below_target"


class Racine(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", padding=dp(10), spacing=dp(10), **kwargs)

        try:
            self.corpus = moteur.charger_corpus()
            accueil = "{} enseignement(s) chargé(s). Pose ta question.".format(len(self.corpus))
        except Exception as e:  # afficher l'erreur plutôt que fermer l'application
            self.corpus = []
            accueil = "Erreur de chargement : {}".format(e)

        self.champ = TextInput(
            hint_text="Pose ta question biblique...",
            multiline=False, size_hint_y=None, height=dp(50), font_size="18sp")
        self.champ.bind(on_text_validate=self.chercher)

        bouton = Button(text="Chercher", size_hint_y=None, height=dp(50), font_size="18sp")
        bouton.bind(on_release=self.chercher)

        self.sortie = Label(
            text=accueil, size_hint_y=None, halign="left", valign="top",
            font_size="16sp", markup=False)
        self.sortie.bind(
            width=lambda *_: setattr(self.sortie, "text_size", (self.sortie.width, None)))
        self.sortie.bind(
            texture_size=lambda *_: setattr(self.sortie, "height", self.sortie.texture_size[1]))

        defilement = ScrollView()
        defilement.add_widget(self.sortie)

        self.add_widget(self.champ)
        self.add_widget(bouton)
        self.add_widget(defilement)

    def chercher(self, *_):
        self.sortie.text = moteur.repondre(self.champ.text, self.corpus)


class LKHApp(App):
    title = "LKH Bible"

    def build(self):
        return Racine()


if __name__ == "__main__":
    LKHApp().run()
