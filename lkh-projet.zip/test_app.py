"""Tests de l'application d'enseignement contrôlé - python test_app.py"""
import json
import tempfile
import unittest
from pathlib import Path

import app
from lkh import charger_lexique

LEX = charger_lexique()
TEXTE_AMOUR = "Dieu aime les hommes. Paul enseigne les croyants."


def memoire_vide():
    d = tempfile.mkdtemp()
    return app.Memoire(Path(d) / "c.json"), Path(d)


class TestRegleDOr(unittest.TestCase):
    """L'IA ne dit que ce qui a été enseigné ET validé."""

    def test_brouillon_jamais_utilise(self):
        m, _ = memoire_vide()
        m.ajouter("L'amour de Dieu", TEXTE_AMOUR, lexique=LEX)
        res = app.chercher("Dieu aime-t-il les hommes ?", m.valides())
        self.assertEqual(res["statut"], "INCONNU")

    def test_valide_restitue_mot_pour_mot(self):
        m, _ = memoire_vide()
        e = m.ajouter("L'amour de Dieu", TEXTE_AMOUR, ["Jean 3:16"], lexique=LEX)
        m.changer_statut(e["id"], "valide")
        res = app.chercher("Dieu aime-t-il les hommes ?", m.valides())
        self.assertEqual(res["statut"], "REPONSE")
        sortie = app.formuler_reponse(res)
        self.assertIn(TEXTE_AMOUR, sortie)          # texte inchangé
        self.assertIn("Jean 3:16", sortie)          # référence du Maître

    def test_hors_sujet_refuse(self):
        m, _ = memoire_vide()
        e = m.ajouter("L'amour de Dieu", TEXTE_AMOUR, lexique=LEX)
        m.changer_statut(e["id"], "valide")
        res = app.chercher("Qui est le roi de France ?", m.valides())
        self.assertEqual(res["statut"], "INCONNU")
        self.assertIn("préfère ne pas inventer", app.formuler_reponse(res))

    def test_retire_n_est_plus_utilise(self):
        m, _ = memoire_vide()
        e = m.ajouter("L'amour de Dieu", TEXTE_AMOUR, lexique=LEX)
        m.changer_statut(e["id"], "valide")
        m.changer_statut(e["id"], "retire")
        self.assertEqual(app.chercher("Dieu aime les hommes", m.valides())["statut"], "INCONNU")

    def test_correction_repasse_en_brouillon(self):
        m, _ = memoire_vide()
        e = m.ajouter("L'amour de Dieu", TEXTE_AMOUR, lexique=LEX)
        m.changer_statut(e["id"], "valide")
        m.modifier(e["id"], texte="Dieu aime tous les hommes.", lexique=LEX)
        self.assertEqual(m.obtenir(e["id"])["statut"], "brouillon")
        self.assertEqual(m.obtenir(e["id"])["version"], 2)
        self.assertEqual(len(m.obtenir(e["id"])["historique"]), 1)


class TestRecherche(unittest.TestCase):
    def test_variantes_de_mots(self):
        m, _ = memoire_vide()
        e = m.ajouter("Le salut", "Le salut est un don de Dieu.", mots_cles=["grâce"], lexique=LEX)
        m.changer_statut(e["id"], "valide")
        self.assertEqual(app.chercher("Qu'est-ce que le salut ?", m.valides())["statut"], "REPONSE")
        self.assertEqual(app.chercher("Parle-moi de la grâce", m.valides())["statut"], "REPONSE")

    def test_question_sans_reponse_est_journalisee(self):
        _, d = memoire_vide()
        chemin = d / "manques.json"
        app.noter_question_sans_reponse("Que dit-on du ciel ?", chemin)
        app.noter_question_sans_reponse("Que dit-on du ciel ?", chemin)
        donnees = json.loads(chemin.read_text(encoding="utf-8"))
        self.assertEqual(len(donnees), 1)
        self.assertEqual(donnees[0]["compte"], 2)

    def test_persistance(self):
        m, d = memoire_vide()
        m.ajouter("Sujet", TEXTE_AMOUR, lexique=LEX)
        m2 = app.Memoire(d / "c.json")
        self.assertEqual(len(m2.entrees), 1)
        self.assertEqual(m2.entrees[0]["texte"], TEXTE_AMOUR)


class TestCoherence(unittest.TestCase):
    def test_contradiction_detectee(self):
        m, _ = memoire_vide()
        a = m.ajouter("Amour", "Dieu aime les hommes.", lexique=LEX)
        m.changer_statut(a["id"], "valide")
        b = m.ajouter("Autre", "Dieu n'aime pas les hommes.", lexique=LEX)
        c = app.trouver_contradictions(b, m.valides())
        self.assertEqual(len(c), 1)
        self.assertEqual(c[0]["entree"]["id"], a["id"])

    def test_pas_de_fausse_alerte(self):
        m, _ = memoire_vide()
        a = m.ajouter("Amour", "Dieu aime les hommes.", lexique=LEX)
        m.changer_statut(a["id"], "valide")
        b = m.ajouter("Autre", "Paul aime les croyants.", lexique=LEX)
        self.assertEqual(app.trouver_contradictions(b, m.valides()), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
