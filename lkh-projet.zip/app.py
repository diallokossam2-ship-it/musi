#!/usr/bin/env python3
"""Application biblique à enseignement contrôlé (sur LKH v0.1.1).

PRINCIPE : l'IA ne répond QU'AVEC ce que le Maître lui a enseigné et validé.
Elle ne génère aucun texte de sa propre initiative : elle restitue mot pour mot
les enseignements validés, avec les références que le Maître a données.
Sans enseignement correspondant, elle dit qu'elle ne sait pas.

Usage :
  python app.py          # mode Maître : enseigner, valider, tester
  python app.py eleve    # mode Élève : poser des questions (aucune modification possible)
"""
import json
import math
import re
import sys
from datetime import datetime
from pathlib import Path

from lkh import analyser, charger_lexique, normaliser, tokeniser

DOSSIER = Path(__file__).parent
CHEMIN_CONNAISSANCES = DOSSIER / "connaissances.json"
CHEMIN_MANQUES = DOSSIER / "questions_sans_reponse.json"

SEUIL_REPONSE = 0.6   # couverture minimale de la question pour répondre
SEUIL_PROCHE = 0.3    # en dessous : "je ne sais pas" ; entre les deux : sujets proches

MOTS_VIDES = set("""a au aux avec ce ces cet cette comme dans de des du elle elles en est et il ils
je la le les leur leurs ma mais me mes moi mon nous on ou par pas plus pour qu que quel quelle quelles
quels qui quoi sa sans se ses son sont sur ta te tes ton tu un une vous y comment pourquoi quand dit dire
dis parle explique expliquer signifie signifier veut peut peux pouvez sais savoir etre fait faut""".split())

SUFFIXES = ("ements", "ement", "ations", "ation", "ions", "ion", "aient", "ait",
            "ons", "ent", "ez", "es", "er", "e", "s", "x", "t")


# ---------------------------------------------------------------- texte

def racine(mot):
    """Racine très simple (aime, aimer, aiment -> aim). Imparfaite, volontairement."""
    for _ in range(2):
        for suf in SUFFIXES:
            if mot.endswith(suf) and len(mot) - len(suf) >= 3:
                mot = mot[: -len(suf)]
                break
    return mot


def racines(texte):
    vus, resultat = set(), []
    for m in tokeniser(texte):
        if len(m) > 1 and m not in MOTS_VIDES:
            r = racine(m)
            if r not in vus:
                vus.add(r)
                resultat.append(r)
    return resultat


def lire_phrases(texte, lexique):
    """Passe chaque phrase dans l'analyseur LKH (pour vérification par le Maître)."""
    morceaux = [p.strip() for p in re.split(r"(?<=[.!?;:])\s+|\n", texte) if p.strip()]
    return [{"phrase": p, "lkh": analyser(p, lexique)} for p in morceaux]


# ---------------------------------------------------------------- mémoire

class Memoire:
    def __init__(self, chemin=CHEMIN_CONNAISSANCES):
        self.chemin = Path(chemin)
        self.entrees = []
        if self.chemin.exists():
            self.entrees = json.loads(self.chemin.read_text(encoding="utf-8"))["entrees"]

    def sauver(self):
        tmp = self.chemin.with_suffix(".tmp")
        tmp.write_text(json.dumps({"entrees": self.entrees}, ensure_ascii=False, indent=2),
                       encoding="utf-8")
        tmp.replace(self.chemin)

    def _maintenant(self):
        return datetime.now().isoformat(timespec="seconds")

    def obtenir(self, ident):
        ident = str(ident).strip().upper()
        if ident.isdigit():
            ident = "E{:03d}".format(int(ident))
        return next((e for e in self.entrees if e["id"] == ident), None)

    def valides(self):
        return [e for e in self.entrees if e["statut"] == "valide"]

    def ajouter(self, sujet, texte, references=None, mots_cles=None, lexique=None):
        lexique = lexique or charger_lexique()
        entree = {
            "id": "E{:03d}".format(len(self.entrees) + 1),
            "sujet": sujet.strip(),
            "texte": texte.strip(),
            "references": [r.strip() for r in (references or []) if r.strip()],
            "mots_cles": [m.strip() for m in (mots_cles or []) if m.strip()],
            "statut": "brouillon",
            "version": 1,
            "cree": self._maintenant(),
            "modifie": self._maintenant(),
            "historique": [],
            "lkh": lire_phrases(texte, lexique),
        }
        self.entrees.append(entree)
        self.sauver()
        return entree

    def modifier(self, ident, sujet=None, texte=None, references=None, mots_cles=None, lexique=None):
        e = self.obtenir(ident)
        if e is None:
            return None
        lexique = lexique or charger_lexique()
        e["historique"].append({"version": e["version"], "sujet": e["sujet"],
                                "texte": e["texte"], "references": e["references"]})
        if sujet:
            e["sujet"] = sujet.strip()
        if texte:
            e["texte"] = texte.strip()
            e["lkh"] = lire_phrases(e["texte"], lexique)
        if references is not None:
            e["references"] = [r.strip() for r in references if r.strip()]
        if mots_cles is not None:
            e["mots_cles"] = [m.strip() for m in mots_cles if m.strip()]
        e["version"] += 1
        e["statut"] = "brouillon"          # toute modification doit être re-validée
        e["modifie"] = self._maintenant()
        self.sauver()
        return e

    def changer_statut(self, ident, statut):
        e = self.obtenir(ident)
        if e is None:
            return None
        e["statut"] = statut
        e["modifie"] = self._maintenant()
        self.sauver()
        return e


# ---------------------------------------------------------------- cohérence doctrinale

def _cle(r):
    return (r["sujet"], r["relation"], r["objet"], r["temps"])


def trouver_contradictions(entree, entrees_valides):
    """Signale les affirmations LKH qui disent l'inverse d'un enseignement déjà validé."""
    miennes = {_cle(x["lkh"]): (x["phrase"], x["lkh"]["polarite"])
               for x in entree["lkh"] if x["lkh"].get("statut") == "RECONNU"}
    trouvees = []
    for autre in entrees_valides:
        if autre["id"] == entree["id"]:
            continue
        for x in autre["lkh"]:
            r = x["lkh"]
            if r.get("statut") != "RECONNU" or _cle(r) not in miennes:
                continue
            phrase, polarite = miennes[_cle(r)]
            if polarite != r["polarite"]:
                trouvees.append({"nouvelle": phrase, "ancienne": x["phrase"], "entree": autre})
    return trouvees


# ---------------------------------------------------------------- recherche (aucune génération)

def chercher(question, entrees):
    """Retourne {statut: REPONSE|PROCHE|INCONNU, resultats: [(score, entree)], proches: [...]}."""
    q = racines(question)
    if not q or not entrees:
        return {"statut": "INCONNU", "resultats": [], "proches": []}

    index = []
    for e in entrees:
        cles = set(racines(e["sujet"] + " " + " ".join(e.get("mots_cles", []))))
        corps = set(racines(e["texte"]))
        index.append((cles, corps))

    n = len(entrees)
    poids = {}
    for r in q:
        df = sum(1 for cles, corps in index if r in cles or r in corps)
        poids[r] = math.log(1 + (n + 1) / (df + 1))
    total = sum(poids.values())

    scores = []
    for e, (cles, corps) in zip(entrees, index):
        s = 0.0
        for r in q:
            if r in cles:
                s += poids[r]
            elif r in corps:
                s += 0.7 * poids[r]
        scores.append((s / total, e))
    scores.sort(key=lambda x: -x[0])

    reponses = [(c, e) for c, e in scores if c >= SEUIL_REPONSE][:3]
    if reponses:
        return {"statut": "REPONSE", "resultats": reponses, "proches": []}
    proches = [e for c, e in scores if c >= SEUIL_PROCHE][:3]
    if proches:
        return {"statut": "PROCHE", "resultats": [], "proches": proches}
    return {"statut": "INCONNU", "resultats": [], "proches": []}


def noter_question_sans_reponse(question, chemin=CHEMIN_MANQUES):
    chemin = Path(chemin)
    donnees = json.loads(chemin.read_text(encoding="utf-8")) if chemin.exists() else []
    cle = normaliser(question).strip()
    for d in donnees:
        if d["cle"] == cle:
            d["compte"] += 1
            break
    else:
        donnees.append({"cle": cle, "question": question.strip(), "compte": 1,
                        "date": datetime.now().isoformat(timespec="seconds")})
    chemin.write_text(json.dumps(donnees, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------- affichage

def formater_entree(e, complet=True):
    ligne = "[{}] {}  ({}, v{})".format(e["id"], e["sujet"], e["statut"], e["version"])
    if not complet:
        return ligne
    texte = ligne + "\n" + e["texte"]
    if e["references"]:
        texte += "\nRéférences (indiquées par mon enseignant) : " + " ; ".join(e["references"])
    return texte


def formuler_reponse(res):
    if res["statut"] == "REPONSE":
        blocs = ["Voici ce que mon enseignant m'a enseigné :"]
        for _, e in res["resultats"]:
            bloc = "\n▸ " + e["sujet"] + "\n" + e["texte"]
            if e["references"]:
                bloc += "\nRéférences (indiquées par mon enseignant) : " + " ; ".join(e["references"])
            blocs.append(bloc)
        return "\n".join(blocs)
    if res["statut"] == "PROCHE":
        titres = "\n".join("  - " + e["sujet"] for e in res["proches"])
        return ("Je n'ai pas appris cela précisément, et je préfère ne pas inventer.\n"
                "Sujets proches que mon enseignant m'a enseignés :\n" + titres +
                "\n(Reformule ta question avec le nom d'un de ces sujets.)")
    return ("Mon enseignant ne m'a pas encore enseigné sur ce sujet, "
            "et je préfère ne pas inventer. Ta question a été notée pour lui.")


def lire_multiligne(invite):
    print(invite + " (termine par une ligne vide)")
    lignes = []
    while True:
        try:
            l = input("  | ")
        except EOFError:
            break
        if not l.strip():
            break
        lignes.append(l)
    return "\n".join(lignes)


def afficher_comprehension(entree):
    print("\nVoici ce que j'ai retenu :")
    for x in entree["lkh"]:
        r = x["lkh"]
        if r.get("statut") == "RECONNU":
            print("  ✓ {}\n      compris comme : {}".format(x["phrase"], r["lisible"]))
        else:
            print("  • {}\n      (conservée telle quelle, pas encore analysée : {})".format(
                x["phrase"], r.get("message", r.get("statut"))))


# ---------------------------------------------------------------- mode Maître

AIDE_MAITRE = """Commandes du Maître :
  enseigner        Apprendre un nouvel enseignement à l'IA
  lister           Voir tous les enseignements (brouillon / valide / retire)
  voir N           Afficher l'enseignement N
  valider N        Autoriser l'IA à enseigner N aux élèves
  corriger N       Modifier N (repasse en brouillon, à re-valider)
  retirer N        Interdire à l'IA d'utiliser N
  manques          Questions posées auxquelles l'IA n'a pas su répondre
  aide / quitter
Toute autre ligne est traitée comme une question de test (l'IA répond comme à un élève)."""


def proposer_validation(m, entree):
    contradictions = trouver_contradictions(entree, m.valides())
    for c in contradictions:
        print("\n⚠ CONTRADICTION POSSIBLE avec {} :".format(c["entree"]["id"]))
        print("   nouveau  : " + c["nouvelle"])
        print("   existant : " + c["ancienne"])
    rep = input("\nValider cet enseignement maintenant ? (o/n) ").strip().lower()
    if rep in ("o", "oui"):
        m.changer_statut(entree["id"], "valide")
        print("✓ {} validé : l'IA pourra désormais l'enseigner.".format(entree["id"]))
    else:
        print("Gardé en brouillon : l'IA ne l'utilisera pas tant qu'il n'est pas validé.")


def cmd_enseigner(m, lex):
    sujet = input("Sujet de l'enseignement : ").strip()
    if not sujet:
        print("Annulé (sujet vide).")
        return
    texte = lire_multiligne("Enseignement")
    if not texte:
        print("Annulé (enseignement vide).")
        return
    refs = input("Références bibliques, séparées par ; (facultatif) : ").split(";")
    mots = input("Mots-clés supplémentaires, séparés par , (facultatif) : ").split(",")
    e = m.ajouter(sujet, texte, refs, mots, lex)
    afficher_comprehension(e)
    proposer_validation(m, e)


def cmd_corriger(m, lex, ident):
    e = m.obtenir(ident)
    if not e:
        print("Enseignement introuvable.")
        return
    print(formater_entree(e))
    print("\n(Appuie sur Entrée pour garder la valeur actuelle.)")
    sujet = input("Nouveau sujet : ").strip() or None
    texte = lire_multiligne("Nouveau texte") or None
    refs = input("Nouvelles références (; ) : ").strip()
    mots = input("Nouveaux mots-clés (, ) : ").strip()
    e = m.modifier(ident, sujet, texte,
                   refs.split(";") if refs else None,
                   mots.split(",") if mots else None, lex)
    afficher_comprehension(e)
    proposer_validation(m, e)


def mode_maitre(m, lex):
    print("=== Mode Maître === (tape 'aide' pour les commandes)")
    while True:
        try:
            ligne = input("\nMaître > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not ligne:
            continue
        cmd, _, reste = ligne.partition(" ")
        cmd = normaliser(cmd)
        if cmd in ("quitter", "exit"):
            break
        elif cmd == "aide":
            print(AIDE_MAITRE)
        elif cmd == "enseigner":
            cmd_enseigner(m, lex)
        elif cmd == "lister":
            if not m.entrees:
                print("Aucun enseignement pour l'instant. Tape 'enseigner'.")
            for e in m.entrees:
                print(formater_entree(e, complet=False))
        elif cmd == "voir":
            e = m.obtenir(reste)
            print(formater_entree(e) if e else "Enseignement introuvable.")
        elif cmd == "valider":
            e = m.obtenir(reste)
            if e:
                proposer = trouver_contradictions(e, m.valides())
                for c in proposer:
                    print("⚠ Contradiction possible avec {} : « {} » / « {} »".format(
                        c["entree"]["id"], c["nouvelle"], c["ancienne"]))
                m.changer_statut(e["id"], "valide")
                print("✓ {} validé.".format(e["id"]))
            else:
                print("Enseignement introuvable.")
        elif cmd == "retirer":
            e = m.changer_statut(reste.strip().upper() if not reste.strip().isdigit()
                                 else "E{:03d}".format(int(reste)), "retire")
            print("✓ Retiré : l'IA n'utilisera plus cet enseignement." if e
                  else "Enseignement introuvable.")
        elif cmd == "corriger":
            cmd_corriger(m, lex, reste)
        elif cmd == "manques":
            if not CHEMIN_MANQUES.exists():
                print("Aucune question sans réponse.")
            else:
                for d in sorted(json.loads(CHEMIN_MANQUES.read_text(encoding="utf-8")),
                                key=lambda d: -d["compte"]):
                    print("({}x) {}".format(d["compte"], d["question"]))
        else:
            res = chercher(ligne, m.valides())
            print("\n" + formuler_reponse(res))
            if res["statut"] != "REPONSE":
                noter_question_sans_reponse(ligne)
    print("Paix à toi.")


# ---------------------------------------------------------------- mode Élève

def mode_eleve(m):
    print("=== Mode Élève ===")
    print("Pose ta question. Je ne réponds qu'avec ce que mon enseignant m'a enseigné.")
    print("Tape 'sujets' pour voir ce que je connais, 'quitter' pour sortir.")
    while True:
        try:
            ligne = input("\nToi > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not ligne:
            continue
        if normaliser(ligne) in ("quitter", "exit"):
            break
        if normaliser(ligne) == "sujets":
            valides = m.valides()
            print("\n".join("  - " + e["sujet"] for e in valides) if valides
                  else "On ne m'a encore rien enseigné.")
            continue
        res = chercher(ligne, m.valides())
        print("\n" + formuler_reponse(res))
        if res["statut"] != "REPONSE":
            noter_question_sans_reponse(ligne)


if __name__ == "__main__":
    memoire = Memoire()
    if len(sys.argv) > 1 and sys.argv[1] == "eleve":
        mode_eleve(memoire)
    else:
        mode_maitre(memoire, charger_lexique())
