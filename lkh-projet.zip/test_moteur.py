"""Tests du moteur - lancer avec : python test_moteur.py"""
import unittest

import moteur

CORPUS = moteur.charger_corpus()


class TestMoteur(unittest.TestCase):
    def test_corpus_charge(self):
        self.assertGreaterEqual(len(CORPUS), 1)

    def test_question_sur_le_sujet(self):
        self.assertIn("Dieu a manifesté", moteur.repondre("Dieu aime-t-il les hommes ?", CORPUS))

    def test_recherche_par_reference(self):
        self.assertIn("Jean 3:16", moteur.repondre("Que dit Jean 3:16 ?", CORPUS))

    def test_sujet_non_enseigne(self):
        self.assertEqual(moteur.repondre("Qui est Satan ?", CORPUS),
                         "Ce point n'a pas encore été enseigné.")

    def test_question_vide(self):
        self.assertEqual(moteur.repondre("   ", CORPUS), "Écris une question.")

    def test_corpus_vide(self):
        self.assertEqual(moteur.repondre("Dieu ?", []), "Aucun enseignement n'est chargé.")


if __name__ == "__main__":
    unittest.main(verbosity=2)
