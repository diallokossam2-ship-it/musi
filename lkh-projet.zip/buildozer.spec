[app]
title = LKH Bible
package.name = lkhbible
package.domain = org.lkh

source.dir = .
source.include_exts = py,json
source.exclude_dirs = .github,bin,.buildozer,__pycache__
source.exclude_patterns = test_*.py,valider.py,app.py

version = 0.1.1
requirements = python3,kivy==2.3.0

orientation = portrait
fullscreen = 0

# 64 bits + 32 bits : beaucoup de téléphones d'entrée de gamme sont en 32 bits
android.archs = arm64-v8a, armeabi-v7a
android.api = 33
android.minapi = 21
android.accept_sdk_license = True

# Aucune permission demandée : l'application fonctionne entièrement hors ligne.

[buildozer]
log_level = 2
warn_on_root = 1
