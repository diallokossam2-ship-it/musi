#!/usr/bin/env python3
"""Validateur des fiches d'enseignement LKH (hors ligne, sans dépendance).

Vérifie :
  - la structure de chaque fiche (champs obligatoires, versets complets) ;
  - que les affirmations/exclusions sont analysables par LKH (sinon avertissement) ;
  - l'absence de contradiction : entre deux affirmations de polarité opposée,
    ou entre une affirmation et une exclusion identique.

Usage : python valider.py            (code de sortie 1 s'il y a des erreurs)
"""
import json
import sys
from pathlib import Path

from lkh import analyser, charger_lexique

DOSSIER = Path(__file__).with_name("enseignements")
CHAMPS_TEXTE = ["id", "theme", "titre", "enseignement"]
STATUTS = {"brouillon", "valide"}


def charger_fiches(dossier, erreurs):
    fiches = []
    for chemin in sorted(Path(dossier).glob("*.json")):
        if chemin.name.startswith("_"):      # _modele.json ignoré
            continue
        try:
            with open(chemin, encoding="utf-8") as f:
                fiches.append((chemin.name, json.load(f)))
        except json.JSONDecodeError as e:
            erreurs.append(f"{chemin.name}: JSON invalide ({e})")
    return fiches


def verifier_structure(nom, fiche, erreurs):
    for champ in CHAMPS_TEXTE:
        if not str(fiche.get(champ, "")).strip():
            erreurs.append(f"{nom}: champ '{champ}' vide ou absent")
    if fiche.get("statut") not in STATUTS:
        erreurs.append(f"{nom}: statut doit être l'un de {sorted(STATUTS)}")

    versets = fiche.get("versets")
    if not isinstance(versets, list) or not versets:
        erreurs.append(f"{nom}: au moins un verset est requis")
    else:
        for i, v in enumerate(versets, 1):
            for cle in ("reference", "texte", "traduction"):
                if not str(v.get(cle, "")).strip():
                    erreurs.append(f"{nom}: verset {i}, champ '{cle}' vide")

    for cle in ("affirmations", "questions_types"):
        if not isinstance(fiche.get(cle), list) or not fiche.get(cle):
            erreurs.append(f"{nom}: '{cle}' doit être une liste non vide")
    if not isinstance(fiche.get("exclusions", []), list):
        erreurs.append(f"{nom}: 'exclusions' doit être une liste")


def verifier(dossier=DOSSIER):
    erreurs, avertissements = [], []
    lex = charger_lexique()
    fiches = charger_fiches(dossier, erreurs)

    ids = {}
    affirme, rejete = {}, {}   # (sujet, relation, objet, temps) -> {polarite: [fiche]}

    for nom, fiche in fiches:
        verifier_structure(nom, fiche, erreurs)
        fid = fiche.get("id")
        if fid in ids:
            erreurs.append(f"{nom}: id '{fid}' déjà utilisé par {ids[fid]}")
        ids[fid] = nom

        for type_, cle, table in (("affirmation", "affirmations", affirme),
                                  ("exclusion", "exclusions", rejete)):
            for phrase in fiche.get(cle, []):
                r = analyser(phrase, lex)
                if r["statut"] != "RECONNU":
                    avertissements.append(
                        f"{nom}: {type_} non analysable par LKH : « {phrase} » ({r['message']})")
                    continue
                triplet = (r["sujet"], r["relation"], r["objet"], r["temps"])
                table.setdefault(triplet, {}).setdefault(r["polarite"], []).append(nom)

    for triplet, pols in affirme.items():
        if len(pols) > 1:
            erreurs.append(f"CONTRADICTION entre affirmations {triplet} : "
                           f"{pols['POSITIVE']} (positif) vs {pols['NEGATIVE']} (négatif)")
        for pol, sources in pols.items():
            if pol in rejete.get(triplet, {}):
                erreurs.append(f"CONTRADICTION {triplet} ({pol}) : affirmé dans {sources} "
                               f"mais exclu dans {rejete[triplet][pol]}")
    return erreurs, avertissements


if __name__ == "__main__":
    erreurs, avertissements = verifier()
    for a in avertissements:
        print("AVERTISSEMENT :", a)
    for e in erreurs:
        print("ERREUR :", e)
    if erreurs:
        print(f"\n{len(erreurs)} erreur(s).")
        sys.exit(1)
    print("\nOK : aucune erreur" + (f", {len(avertissements)} avertissement(s)." if avertissements else "."))
