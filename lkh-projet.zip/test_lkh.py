"""Tests LKH v0.1.1 - lancer avec : python test_lkh.py"""
import unittest
from lkh import analyser, charger_lexique, normaliser

LEX = charger_lexique()


def a(phrase):
    return analyser(phrase, LEX)


class TestSpecification(unittest.TestCase):
    def test_identifiants_alignes_sur_la_spec(self):
        r = a("Paul aime les croyants.")
        self.assertEqual(r["statut"], "RECONNU")
        self.assertEqual(r["sujet"], "C002")      # PAUL
        self.assertEqual(r["relation"], "R001")   # AIME
        self.assertEqual(r["objet"], "C004")      # CROYANT
        self.assertEqual(r["temps"], "PRESENT")
        self.assertEqual(r["polarite"], "POSITIVE")

    def test_dieu_hommes(self):
        r = a("Dieu aime les hommes.")
        self.assertEqual((r["sujet"], r["objet"]), ("C001", "C003"))


class TestNegation(unittest.TestCase):
    def test_negation_apostrophe_droite(self):
        r = a("Paul n'aime pas les croyants.")
        self.assertEqual(r["polarite"], "NEGATIVE")
        self.assertEqual(r["relation"], "R001")

    def test_negation_apostrophe_typographique(self):
        self.assertEqual(a("Paul n’aime pas les croyants.")["polarite"], "NEGATIVE")

    def test_negation_incomplete_signalee(self):
        self.assertEqual(a("Paul n'aime les croyants.")["statut"], "PARTIEL")


class TestNormalisation(unittest.TestCase):
    def test_accents(self):
        self.assertEqual(normaliser("Jésus"), "jesus")

    def test_jesus_reconnu(self):
        r = a("Jésus enseigne les hommes.")
        self.assertEqual(r["statut"], "RECONNU")
        self.assertEqual((r["sujet"], r["relation"], r["objet"]), ("C005", "R002", "C003"))

    def test_plan_b_sans_unicodedata(self):
        import lkh
        sauvegarde = lkh.unicodedata
        lkh.unicodedata = None
        try:
            self.assertEqual(lkh.normaliser("Jésus ÉCOUTE l’Église"), "jesus ecoute l'eglise")
            self.assertEqual(lkh.analyser("Jésus enseigne les hommes.", LEX)["statut"], "RECONNU")
        finally:
            lkh.unicodedata = sauvegarde

    def test_majuscules(self):
        self.assertEqual(a("PAUL AIME LES CROYANTS")["statut"], "RECONNU")


class TestPassif(unittest.TestCase):
    def test_passif_inverse_sujet_et_objet(self):
        r = a("Les croyants sont aimés par Paul.")
        self.assertEqual(r["statut"], "RECONNU")
        self.assertEqual((r["sujet"], r["objet"]), ("C002", "C004"))

    def test_passif_equivalent_a_l_actif(self):
        actif, passif = a("Dieu aime les hommes."), a("Les hommes sont aimés par Dieu.")
        for cle in ("sujet", "relation", "objet", "temps", "polarite"):
            self.assertEqual(actif[cle], passif[cle])

    def test_passif_negatif(self):
        r = a("Les croyants ne sont pas aimés par Paul.")
        self.assertEqual(r["polarite"], "NEGATIVE")
        self.assertEqual((r["sujet"], r["objet"]), ("C002", "C004"))

    def test_passif_sans_agent(self):
        self.assertEqual(a("Les croyants sont aimés.")["statut"], "INCOMPLET")


class TestHonnetete(unittest.TestCase):
    """Règle d'or : ne pas inventer le sens."""

    def test_verbe_inconnu(self):
        self.assertEqual(a("Paul mange les croyants.")["statut"], "INCONNU")

    def test_concept_inconnu(self):
        r = a("Paul aime les anges.")
        self.assertEqual(r["statut"], "PARTIEL")
        self.assertIn("anges", r["message"])

    def test_sujet_ambigu(self):
        self.assertEqual(a("Paul, le disciple de Jésus, aime les croyants.")["statut"], "PARTIEL")

    def test_objet_manquant(self):
        self.assertEqual(a("Paul aime.")["statut"], "INCOMPLET")

    def test_sujet_manquant(self):
        self.assertEqual(a("Aime les croyants.")["statut"], "INCOMPLET")

    def test_phrase_vide(self):
        self.assertEqual(a("")["statut"], "INCONNU")


class TestLexique(unittest.TestCase):
    def test_pas_de_forme_ambigue(self):
        # charger_lexique lève une erreur si une forme pointe vers deux concepts
        charger_lexique()

    def test_temps(self):
        self.assertEqual(a("Dieu aimait les hommes.")["temps"], "PASSE")
        self.assertEqual(a("Dieu aimera les hommes.")["temps"], "FUTUR")


if __name__ == "__main__":
    unittest.main(verbosity=2)
