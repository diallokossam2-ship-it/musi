"""Moteur de recherche hors ligne sur les fiches d'enseignement (Python pur).

Il ne génère aucun texte : il retrouve et affiche TES enseignements et leurs versets.
Si rien ne correspond, il le dit.
"""
import json
import re
from pathlib import Path

from lkh import normaliser

DOSSIER = Path(__file__).with_name("enseignements")

# Pendant les tests, les brouillons sont acceptés.
# EN PRODUCTION : remplacer par {"valide"} pour ne servir que les enseignements validés.
STATUTS_ACCEPTES = {"valide", "brouillon"}

SEUIL = 2      # score minimal pour considérer qu'un enseignement correspond
MAX_RESULTATS = 3

MOTS_VIDES = {
    "le", "la", "les", "l", "un", "une", "des", "du", "de", "d", "et", "est", "que", "qui",
    "quoi", "qu", "dit", "il", "elle", "ils", "ce", "cette", "ces", "a", "au", "aux", "en",
    "dans", "pour", "par", "sur", "je", "tu", "nous", "vous", "t", "se", "ne", "pas", "comment",
    "pourquoi", "quel", "quelle", "quels", "quelles", "y", "ou", "on", "mon", "ma", "mes",
    "son", "sa", "ses", "si", "plus", "ai", "as",
}


def _mots(texte):
    """Mots normalisés (sans accents, sans pluriel simple), sans mots vides."""
    resultat = set()
    for m in re.findall(r"[a-z0-9]+", normaliser(texte)):
        if m in MOTS_VIDES:
            continue
        if len(m) > 3 and m.endswith(("s", "x")):
            m = m[:-1]
        resultat.add(m)
    return resultat


def charger_corpus(dossier=DOSSIER):
    corpus = []
    for chemin in sorted(Path(dossier).glob("*.json")):
        if chemin.name.startswith("_"):
            continue
        with open(chemin, encoding="utf-8") as f:
            fiche = json.load(f)
        if fiche.get("statut") not in STATUTS_ACCEPTES:
            continue
        versets = fiche.get("versets", [])
        fiche["_poids"] = {
            3: _mots(" ".join(fiche.get("mots_cles", []))
                     + " " + " ".join(v.get("reference", "") for v in versets)),
            2: _mots(fiche.get("titre", "") + " " + fiche.get("theme", "")),
            1: _mots(fiche.get("enseignement", "")
                     + " " + " ".join(v.get("texte", "") for v in versets)
                     + " " + " ".join(fiche.get("questions_types", []))),
        }
        corpus.append(fiche)
    return corpus


def chercher(question, corpus):
    mots_question = _mots(question)
    classement = []
    for fiche in corpus:
        score = sum(poids for poids, mots in fiche["_poids"].items()
                    for m in mots_question if m in mots)
        if score >= SEUIL:
            classement.append((score, fiche))
    classement.sort(key=lambda x: -x[0])
    return [f for _, f in classement[:MAX_RESULTATS]]


def formater(fiche):
    lignes = [fiche["titre"], "", fiche["enseignement"]]
    if fiche.get("versets"):
        lignes += ["", "Versets :"]
        for v in fiche["versets"]:
            lignes.append("- {} ({}) : {}".format(v["reference"], v["traduction"], v["texte"]))
    return "\n".join(lignes)


def repondre(question, corpus):
    if not question.strip():
        return "Écris une question."
    if not corpus:
        return "Aucun enseignement n'est chargé."
    trouves = chercher(question, corpus)
    if not trouves:
        return "Ce point n'a pas encore été enseigné."
    return "\n\n==========\n\n".join(formater(f) for f in trouves)
