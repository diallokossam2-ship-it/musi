#!/usr/bin/env python3
"""LKH v0.1.1 - Langage du Royaume des Cieux (prototype symbolique hors ligne).

Corrections par rapport à v0.1 :
  - identifiants alignés sur la spécification (C004 = CROYANT) ;
  - normalisation des accents (Jésus -> jesus) et des apostrophes (n’aime / n'aime) ;
  - voix passive gérée ("Les croyants sont aimés par Paul") ;
  - phrases ambiguës signalées (PARTIEL) au lieu d'être devinées ;
  - dictionnaire sorti dans lexique.json.

Usage :
  python lkh.py                      # exemples de démonstration
  python lkh.py "Paul aime les croyants."
"""
import json
import re
import sys

try:
    import unicodedata
except ImportError:      # certaines versions de Python embarquées sur Android
    unicodedata = None
from pathlib import Path

CHEMIN_LEXIQUE = Path(__file__).with_name("lexique.json")

ARTICLES = {"le", "la", "les", "l", "un", "une", "des", "du", "de", "d", "aux", "au"}
NEGATEURS_AVANT = {"ne", "n"}
NEGATEURS_APRES = {"pas", "plus", "jamais"}
PREPOSITIONS = {"en", "par"}
MOTS_OUTILS = ARTICLES | NEGATEURS_AVANT | NEGATEURS_APRES | PREPOSITIONS
AUXILIAIRES_PASSIF = {
    "est": "PRESENT", "sont": "PRESENT",
    "etait": "PASSE", "etaient": "PASSE",
    "sera": "FUTUR", "seront": "FUTUR",
}


# ---------------------------------------------------------------- texte

# Plan B si unicodedata est indisponible
_ACCENTS = str.maketrans("àâäáãçéèêëíìîïñóòôöõúùûüýÿ", "aaaaaceeeeiiiinooooouuuuyy")

def normaliser(texte):
    """Minuscules, sans accents, apostrophes typographiques unifiées."""
    texte = texte.replace("’", "'").replace("‘", "'").replace("`", "'")
    texte = texte.replace("œ", "oe").replace("Œ", "oe")
    if unicodedata is None:
        return texte.lower().translate(_ACCENTS)
    decompose = unicodedata.normalize("NFD", texte)
    sans_accents = "".join(c for c in decompose if not unicodedata.combining(c))
    return sans_accents.lower()


def tokeniser(phrase):
    # "n'aime" -> "n", "aime" ; "l'homme" -> "l", "homme"
    return re.findall(r"[a-z]+", normaliser(phrase))


# ---------------------------------------------------------------- lexique

def charger_lexique(chemin=CHEMIN_LEXIQUE):
    with open(chemin, encoding="utf-8") as f:
        brut = json.load(f)

    lex = {"concepts": {}, "noms_concepts": {}, "noms_relations": {},
           "verbes": {}, "participes": {}}

    for cid, info in brut["concepts"].items():
        lex["noms_concepts"][cid] = info["nom"]
        for forme in info["formes"]:
            f = normaliser(forme)
            if f in lex["concepts"] and lex["concepts"][f] != cid:
                raise ValueError(f"Forme ambiguë '{f}' : {lex['concepts'][f]} et {cid}")
            lex["concepts"][f] = cid

    for rid, info in brut["relations"].items():
        lex["noms_relations"][rid] = info["nom"]
        for forme, temps in info["verbes"].items():
            lex["verbes"][normaliser(forme)] = (rid, temps)
        for forme in info.get("participes", []):
            lex["participes"][normaliser(forme)] = rid

    return lex


# ---------------------------------------------------------------- analyse

def _contenu(zone):
    return [m for m in zone if m not in MOTS_OUTILS]


def _chercher_passif(mots, lex):
    """Retourne (i_aux, j_participe, relation, temps) ou None."""
    for i, mot in enumerate(mots):
        if mot in AUXILIAIRES_PASSIF:
            j = i + 1
            while j < len(mots) and mots[j] in NEGATEURS_APRES:
                j += 1
            if j < len(mots) and mots[j] in lex["participes"]:
                return i, j, lex["participes"][mots[j]], AUXILIAIRES_PASSIF[mot]
    return None


def analyser(phrase, lexique=None):
    lex = lexique or charger_lexique()
    mots = tokeniser(phrase)

    if not mots:
        return {"statut": "INCONNU", "message": "Phrase vide"}

    passif = _chercher_passif(mots, lex)

    if passif:
        i, j, relation, temps = passif
        gauche, droite = mots[:i], mots[j + 1:]
        if not droite or droite[0] != "par":
            return {"statut": "INCOMPLET", "message": "Voix passive sans agent ('par ...')"}
        zone_sujet, zone_objet = droite, gauche           # l'agent agit sur le patient
        negation_avant = any(m in NEGATEURS_AVANT for m in gauche)
        negation_apres = any(m in NEGATEURS_APRES for m in mots[i + 1:j])
    else:
        index = next((k for k, m in enumerate(mots) if m in lex["verbes"]), None)
        if index is None:
            return {"statut": "INCONNU", "message": "Verbe non reconnu"}
        relation, temps = lex["verbes"][mots[index]]
        gauche, droite = mots[:index], mots[index + 1:]
        zone_sujet, zone_objet = gauche, droite
        negation_avant = any(m in NEGATEURS_AVANT for m in gauche)
        negation_apres = any(m in NEGATEURS_APRES for m in droite)

    if negation_avant != negation_apres:
        return {"statut": "PARTIEL", "message": "Négation incomplète ou ambiguë (ne ... pas)"}

    sujets, objets = _contenu(zone_sujet), _contenu(zone_objet)

    if not sujets:
        return {"statut": "INCOMPLET", "message": "Sujet manquant"}
    if not objets:
        return {"statut": "INCOMPLET", "message": "Objet manquant"}
    if len(sujets) > 1 or len(objets) > 1:
        return {"statut": "PARTIEL", "sujet": sujets, "objet": objets,
                "message": "Structure trop complexe pour LKH v0.1 : plusieurs mots candidats"}

    concept_sujet = lex["concepts"].get(sujets[0])
    concept_objet = lex["concepts"].get(objets[0])
    if not concept_sujet or not concept_objet:
        inconnus = [m for m, c in ((sujets[0], concept_sujet), (objets[0], concept_objet)) if not c]
        return {"statut": "PARTIEL", "sujet": sujets[0], "objet": objets[0],
                "message": "Concept absent du dictionnaire : " + ", ".join(inconnus)}

    negatif = negation_avant and negation_apres
    return {
        "langage": "LKH",
        "version": "0.1.1",
        "statut": "RECONNU",
        "sujet": concept_sujet,
        "relation": relation,
        "objet": concept_objet,
        "temps": temps,
        "polarite": "NEGATIVE" if negatif else "POSITIVE",
        "lisible": "{}{} {} {}".format(
            "NON " if negatif else "",
            lex["noms_concepts"][concept_sujet],
            lex["noms_relations"][relation],
            lex["noms_concepts"][concept_objet]),
    }


# ---------------------------------------------------------------- démo

EXEMPLES = [
    "Paul aime les croyants.",
    "Paul n'aime pas les croyants.",
    "Paul n’aime pas les croyants.",
    "Dieu aime les hommes.",
    "Jésus enseigne les hommes.",
    "Les croyants sont aimés par Paul.",
    "Paul, le disciple de Jésus, aime les croyants.",
    "Paul mange les croyants.",
]

if __name__ == "__main__":
    phrases = sys.argv[1:] or EXEMPLES
    lexique = charger_lexique()
    for p in phrases:
        print("\nPhrase :", p)
        print(json.dumps(analyser(p, lexique), ensure_ascii=False, indent=2))
